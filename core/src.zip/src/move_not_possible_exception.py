class MoveNotPossibleException(Exception):
    pass
